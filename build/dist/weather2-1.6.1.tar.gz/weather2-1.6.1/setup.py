from setuptools import setup
setup(name='weather2',
    version='1.6.1',
    author='Adam Jenca',
    description='Access weather forecast',
    long_description=
'''
# weather - Access weather forecast
## Installation
```
pip install weather
```
## Usage
```python
import weather
forecast=weather.forecast()
forecast.today['6:00'].temp # Get temperature in current location at 6.00
```
### Different places
If you want to get forecast from different place, pass `forecast` an argument.
```python
import weather
forecast=weather.forecast('New York')
forecast.tommorow['11:00'].precip # Get precipitation in New York at 11.00
```
### Different sources
`weather` supports two weather sources:
1. [Yr.No](https://yr.no)
1. [7timer!](https://7timer.info)
If you want to get weather from different source, pass `forecast` argument called `source`.
```python
weather.forecast(source='yrno')
weather.forecast(source='google')
weather.forecast(source='7timer')
```
### Weather properties
<ol>
  <li>
    <p><code>wind</code>: Instance of <code>Wind()</code></p>
    Properties:
    <ol>
      <li>
        <p><code>speed</code>: Integer</p>
        Speed in m/s
      </li>
      <li>
        <p><code>direction</code>: Instance of <code>Direction()</code></p>
        Properties:
        <ol>
          <li>
            <p><code>angle</code>: Integer</p>
            Angle in degrees
          </li>
          <li>
            <p><code>direction</code>: String</p>
            Angle in compass point (<code>'N'</code>,<code>'NE'</code>,<code>'E'</code>,<code>'SE'</code>,<code>'S'</code>,<code>'SW'</code>,
            <code>'W'</code>, or <code>'NW'</code>)
          </li>
        </ol>
      </li>
    </ol>
  </li>
  <li>
    <p><code>temp</code>: Float/Integer</p>
      Temperature in °C or °F (not °K) (default °C, see 'Changing units')
  </li>
  <li>
    <p><code>humid</code> (<code>yr.no</code> only, other services will return <code>None</code>): Float/Integer</p>
      Humidity in %.
  </li>
  <li>
    <p><code>precip</code> (<code>7timer</code> will return <code>bool</code>): Float/Integer</p>
      Precipitation amount in milimeters
</ol>

### Changing units
```python
weather.forecast('New york', unit=weather.CELSIUS)#or weather.FAHRENHEIT
```
### CLI
Just run `weather`:
    ```[user@localhost ~] weather```
If you want to get all avaliable switches, use `weather -h`:

```python
usage: weather [-h] [--city CITY] [--country COUNTRY] [-d] [-s SERVICE]
                   [-u] [-a]

Python app for getting weather forecast

options:
  -h, --help            show this help message and exit
  --city CITY           City for forecast (if not passed, using current
                        location)
  --country COUNTRY     Country for forecast (see above)
  -d, --debug           Debug
  -s SERVICE, --service SERVICE
                        Service to use ("yrno" or "7timer"). Implied with
                        "average"(try to optimise the service)
  -u, --ugly            Toggle JSON output
  -a, --api             Just print the data (implies JSON output)

``` 
That says basically enough to use it.

### License

`weather` is licensed under *GPL license*
''',
    long_description_content_type='text/markdown',
    classifiers=[
                "Development Status :: 4 - Beta",
                "Environment :: Console",
                "Intended Audience :: Developers",
                "Intended Audience :: End Users/Desktop",
                "License :: OSI Approved :: GNU General Public License (GPL)",
                "Operating System :: OS Independent",
                "Programming Language :: Python",
                "Programming Language :: Python :: 3",
                ],
    entry_points={
    'console_scripts': [
        'weather = weather:main',
    ]},
    author_email="jenca.adam@gmail.com",
    url="https://github.com/jenca-adam/weather",
    packages=['weather'],
    install_requires=['urllib3','bs4','httplib2','geopy','selenium','colorama','lxml','langdetect','termcolor','tabulate','termutils','get-key','unitconvert']


    
)

       
