
### Weather properties
1. `wind`
Instance of `Wind()`
Properties:
1. `speed`
Integer
Speed in m/s
2. `direction`
Instance of Direction()
Properties:
1. `angle`
    Integer
    Angle in degrees
2. `direction`
    String
    Angle in compass point ( 'N','NE','E','SE','S','SW','W', or 'NW' )
2. `temp`
      Float/Integer
      Temperature in °C or °F (not °K)(default °C, see 'Changing units')
3. `humid`(yr.no only, other services will return None)
      Float/Integer
      Humidity in %.
4. `precip`(7timer will return bool)
      Float/Integer
      Precipitation amount in milimeters
### Changing units
